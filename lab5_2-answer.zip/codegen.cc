#include "tiger/codegen/codegen.h"

#include <cassert>
#include <sstream>

extern frame::RegManager *reg_manager;

namespace {

constexpr int maxlen = 1024;

} // namespace

namespace cg {
  // 将 reg 寄存器中的值压入当前的栈顶
void CodeGen::SaveRegToStack(assem::InstrList &list, temp::Temp *reg) {
  frame_->offset_ -= reg_manager->WordSize();
  int word_size = reg_manager->WordSize();

  list.Append(new assem::OperInstr(
      "subq $" + std::to_string(word_size) + ", `d0",
      new temp::TempList(reg_manager->StackPointer()), nullptr, nullptr));

  list.Append(new assem::OperInstr(
      "movq `s0, (`d0)",
      new temp::TempList(reg_manager->StackPointer()),
      new temp::TempList(reg), nullptr));
}
// void CodeGen::PushRegOnStack(assem::InstrList &instr_list, temp::Temp *reg) {
//   frame_->offset_ -= reg_manager->WordSize();
//   instr_list.Append(new assem::OperInstr(
//       "subq $" + std::to_string(reg_manager->WordSize()) + ", `d0",
//       new temp::TempList(reg_manager->StackPointer()), nullptr, nullptr));
//   instr_list.Append(new assem::OperInstr(
//       "movq `s0, (`d0)", new temp::TempList(reg_manager->StackPointer()),
//       new temp::TempList(reg), nullptr));
// }

// 从当前栈顶恢复一个值到寄存器 reg，并移动栈顶指针
void CodeGen::RestoreRegFromStack(assem::InstrList &list, temp::Temp *reg) {
  int word_size = reg_manager->WordSize();

  list.Append(new assem::OperInstr(
      "movq (`s0), `d0",
      new temp::TempList(reg),
      new temp::TempList(reg_manager->StackPointer()), nullptr));

  list.Append(new assem::OperInstr(
      "addq $" + std::to_string(word_size) + ", `d0",
      new temp::TempList(reg_manager->StackPointer()), nullptr, nullptr));
}


// void CodeGen::PopRegFromStack(assem::InstrList &instr_list, temp::Temp *reg) {
//   instr_list.Append(new assem::OperInstr(
//       "movq (`s0), `d0", new temp::TempList(reg),
//       new temp::TempList(reg_manager->StackPointer()), nullptr));
//   instr_list.Append(new assem::OperInstr(
//       "addq $" + std::to_string(reg_manager->WordSize()) + ", `d0",
//       new temp::TempList(reg_manager->StackPointer()), nullptr, nullptr));
// }

// 将 src 寄存器的值保存到地址由 base 指向的位置上
void CodeGen::SaveRegToAddress(assem::InstrList &list, temp::Temp *base,
                               temp::Temp *src) {
  frame_->offset_ -= reg_manager->WordSize();
  int word_size = reg_manager->WordSize();

  list.Append(new assem::OperInstr(
      "subq $" + std::to_string(word_size) + ", `d0",
      new temp::TempList(base), nullptr, nullptr));

  list.Append(new assem::OperInstr(
      "movq `s0, (`d0)",
      new temp::TempList(base),
      new temp::TempList(src), nullptr));
}

// void CodeGen::PushRegToPos(assem::InstrList &instr_list, temp::Temp *pos,
//                            temp::Temp *to_be_push) {
//   frame_->offset_ -= reg_manager->WordSize();
//   instr_list.Append(new assem::OperInstr(
//       "subq $" + std::to_string(reg_manager->WordSize()) + ", `d0",
//       new temp::TempList(pos), nullptr, nullptr));
//   instr_list.Append(
//       new assem::OperInstr("movq `s0, (`d0)", new temp::TempList(pos),
//                            new temp::TempList(to_be_push), nullptr));
// }

// 从地址 base 指向的位置恢复一个值到 dst 寄存器。
void CodeGen::RestoreRegFromAddress(assem::InstrList &list, temp::Temp *base,
                                    temp::Temp *dst) {
  int word_size = reg_manager->WordSize();

  list.Append(new assem::OperInstr(
      "subq $" + std::to_string(word_size) + ", `d0",
      new temp::TempList(base), nullptr, nullptr));

  list.Append(new assem::OperInstr(
      "movq (`s0), `d0",
      new temp::TempList(dst),
      new temp::TempList(base), nullptr));
}
// void CodeGen::PopRegFromPos(assem::InstrList &instr_list, temp::Temp *pos,
//                             temp::Temp *to_be_pop) {
//   instr_list.Append(new assem::OperInstr(
//       "subq $" + std::to_string(reg_manager->WordSize()) + ", `d0",
//       new temp::TempList(pos), nullptr, nullptr));
//   instr_list.Append(new assem::OperInstr("movq (`s0), `d0",
//                                          new temp::TempList(to_be_pop),
//                                          new temp::TempList(pos), nullptr));
// }

void CodeGen::Codegen() {
  fs_ = frame_->GetLabel() + "_framesize"; // // Frame size label_
  auto instr_list = new assem::InstrList();

  // Save callee-saved registers
  auto pos = reg_manager->GetRegister(frame::X64RegManager::X64Reg::RAX);
  instr_list->Append(new assem::OperInstr("leaq " + fs_ + "(%rsp), `d0",
                                          new temp::TempList(pos), nullptr,
                                          nullptr));
  instr_list->Append(
      new assem::OperInstr("addq $" + std::to_string(frame_->offset_) + ", `d0",
                           new temp::TempList(pos), nullptr, nullptr));
  for (auto callee_save_reg : reg_manager->CalleeSaves()->GetList()) {
    SaveRegToAddress(*instr_list, pos, callee_save_reg);
  }

  // Init FP with SP
  // FP = SP + fs
  instr_list->Append(new assem::OperInstr(
      "leaq " + fs_ + "(`s0), `d0",
      new temp::TempList(reg_manager->FramePointer()),
      new temp::TempList(reg_manager->StackPointer()), nullptr));

  // Munch
  for (auto stm : traces_->GetStmList()->GetList()) {
    stm->Munch(*instr_list, fs_);
  }

  // Restore callee-saved registers
  auto pos_rbx = reg_manager->GetRegister(frame::X64RegManager::X64Reg::RBX);
  auto li = reg_manager->CalleeSaves()->GetList();
  instr_list->Append(new assem::OperInstr("leaq " + fs_ + "(%rsp), `d0",
                                          new temp::TempList(pos_rbx), nullptr,
                                          nullptr));
  instr_list->Append(new assem::OperInstr(
      "addq $" +
          std::to_string(frame_->offset_ +
                         li.size() * reg_manager->WordSize()) +
          ", `d0",
      new temp::TempList(pos_rbx), nullptr, nullptr));
  for (auto callee_save_reg : li) {
    RestoreRegFromAddress(*instr_list, pos_rbx, callee_save_reg);
  }

  assem_instr_ =
      std::make_unique<AssemInstr>(frame::ProcEntryExit2(instr_list));
}

void AssemInstr::Print(FILE *out, temp::Map *map) const {
  for (auto instr : instr_list_->GetList())
    instr->Print(out, map);
  fprintf(out, "\n");
}
} // namespace cg

namespace tree {
/* TODO: Put your lab5 code here */

void SeqStm::Munch(assem::InstrList &instr_list, std::string_view fs) {
  left_->Munch(instr_list, fs);
  right_->Munch(instr_list, fs);
}

void LabelStm::Munch(assem::InstrList &instr_list, std::string_view fs) {
  instr_list.Append(
      new assem::LabelInstr(temp::LabelFactory::LabelString(label_), label_));
}

void JumpStm::Munch(assem::InstrList &instr_list, std::string_view fs) {
  auto dst_label = exp_->name_->Name();
  assem::Instr *instr = new assem::OperInstr(
      "jmp " + dst_label, nullptr, nullptr, new assem::Targets(jumps_));
  instr_list.Append(instr);
}

void CjumpStm::Munch(assem::InstrList &instr_list, std::string_view fs) {
  temp::Temp *left = left_->Munch(instr_list, fs);
  temp::Temp *right = right_->Munch(instr_list, fs);
  // s0 - s1 (left - right)
  instr_list.Append(new assem::OperInstr(
      "cmpq `s1, `s0", nullptr, new temp::TempList({left, right}), nullptr));
  std::string cjump_instr;
  switch (op_) {
  case EQ_OP:
    cjump_instr = "je";
    break;
  case NE_OP:
    cjump_instr = "jne";
    break;
  case LT_OP:
    cjump_instr = "jl";
    break;
  case GT_OP:
    cjump_instr = "jg";
    break;
  case LE_OP:
    cjump_instr = "jle";
    break;
  case GE_OP:
    cjump_instr = "jge";
    break;
  case ULT_OP:
    cjump_instr = "jnb";
    break;
  case ULE_OP:
    cjump_instr = "jnbe";
    break;
  case UGT_OP:
    cjump_instr = "jna";
    break;
  case UGE_OP:
    cjump_instr = "jnae";
    break;
  case REL_OPER_COUNT:
  default:
    assert(0);
  }
  instr_list.Append(
      new assem::OperInstr(cjump_instr + " `j0", nullptr, nullptr,
                           new assem::Targets(new std::vector<temp::Label *>{
                               true_label_, false_label_})));
}

void MoveStm::Munch(assem::InstrList &instr_list, std::string_view fs) {
  temp::Temp *src = src_->Munch(instr_list, fs);
  if (typeid(*dst_) == typeid(tree::MemExp)) {
    // deal with dst is mem
    // directly move to mem
    temp::Temp *dst = ((MemExp *)dst_)->exp_->Munch(instr_list, fs);
    instr_list.Append(new assem::MoveInstr("movq `s0, (`s1)", nullptr,
                                           new temp::TempList({src, dst})));
  } else {
    // dst is reg
    // if src is mem exp, src_->Munch will deal with this
    temp::Temp *dst = dst_->Munch(instr_list, fs);
    instr_list.Append(new assem::MoveInstr(
        "movq `s0, `d0", new temp::TempList({dst}), new temp::TempList({src})));
  }
}

void ExpStm::Munch(assem::InstrList &instr_list, std::string_view fs) {
  exp_->Munch(instr_list, fs);
}

temp::Temp *BinopExp::Munch(assem::InstrList &instr_list, std::string_view fs) {
  std::string op_instr;
  switch (op_) {
  case PLUS_OP:
    op_instr = "addq";
    break;
  case MINUS_OP:
    op_instr = "subq";
    break;
  case MUL_OP:
    op_instr = "imulq";
    break;
  case DIV_OP:
    op_instr = "idivq";
    break;
  case AND_OP:
    op_instr = "andq";
    break;
  case OR_OP:
    op_instr = "orq";
    break;
  case LSHIFT_OP:
    op_instr = "salq";
    break;
  case RSHIFT_OP:
    op_instr = "shrq";
    break;
  case ARSHIFT_OP:
    op_instr = "sarq";
    break;
  case XOR_OP:
    op_instr = "xorq";
    break;
  case BIN_OPER_COUNT:
  default:
    assert(0);
  }
  temp::Temp *left = left_->Munch(instr_list, fs);
  temp::Temp *right = right_->Munch(instr_list, fs);
  temp::Temp *reg = temp::TempFactory::NewTemp();
  temp::TempList *result = new temp::TempList(reg);
  temp::Temp *rax = reg_manager->GetRegister(frame::X64RegManager::X64Reg::RAX);
  temp::Temp *rdx = reg_manager->GetRegister(frame::X64RegManager::X64Reg::RDX);
  if (op_ == BinOp::MUL_OP) {
    // imulq S
    // R[%rdx]:R[%rax] <- S * R[%rax]
    instr_list.Append(new assem::MoveInstr(
        "movq `s0, `d0", new temp::TempList(rax), new temp::TempList(left)));
    instr_list.Append(new assem::OperInstr("imulq `s0",
                                           new temp::TempList({rax, rdx}),
                                           new temp::TempList(right), nullptr));
    instr_list.Append(new assem::MoveInstr(
        "movq `s0, `d0", new temp::TempList(reg), new temp::TempList(rax)));
    return reg;
  } else {
    if (op_ == BinOp::DIV_OP) {
      // idivq S
      // R[%rdx] <- R[%rdx]:R[%rax] mod S
      // R[%rax] <- R[%rdx]:R[%rax] / S
      instr_list.Append(new assem::MoveInstr(
          "movq `s0, `d0", new temp::TempList(rax), new temp::TempList(left)));
      instr_list.Append(new assem::OperInstr("cqto", new temp::TempList(rdx),
                                             new temp::TempList(rax), nullptr));
      instr_list.Append(
          new assem::OperInstr("idivq `s0", new temp::TempList({rax, rdx}),
                               new temp::TempList(right), nullptr));
      instr_list.Append(new assem::MoveInstr(
          "movq `s0, `d0", new temp::TempList(reg), new temp::TempList(rax)));
      return reg;
    } else {
      instr_list.Append(new assem::MoveInstr("movq `s0, `d0", result,
                                             new temp::TempList(left)));
      instr_list.Append(new assem::OperInstr(
          op_instr + " `s0, `d0", result, new temp::TempList(right), nullptr));
      return reg;
    }
  }
}

temp::Temp *MemExp::Munch(assem::InstrList &instr_list, std::string_view fs) {
  // only deal with src is mem
  temp::Temp *reg = temp::TempFactory::NewTemp();
  temp::Temp *exp = exp_->Munch(instr_list, fs);
  instr_list.Append(new assem::OperInstr("movq (`s0), `d0",
                                         new temp::TempList(reg),
                                         new temp::TempList(exp), nullptr));
  return reg;
}

temp::Temp *TempExp::Munch(assem::InstrList &instr_list, std::string_view fs) {
  if (temp_ != reg_manager->FramePointer()) {
    return temp_;
  }

  // modify FP to SP + frame_size since we do not have FP
  temp::Temp *fp = temp::TempFactory::NewTemp();
  std::stringstream assem;
  assem << "leaq " << fs << "(`s0), `d0";
  instr_list.Append(new assem::OperInstr(
      assem.str(), new temp::TempList(fp),
      new temp::TempList(reg_manager->StackPointer()), nullptr));
  return fp;
}

temp::Temp *EseqExp::Munch(assem::InstrList &instr_list, std::string_view fs) {
  stm_->Munch(instr_list, fs);
  return exp_->Munch(instr_list, fs);
}

temp::Temp *NameExp::Munch(assem::InstrList &instr_list, std::string_view fs) {
  /* TODO: Put your lab5 code here */
  temp::Temp *dst = temp::TempFactory::NewTemp();
  instr_list.Append(
      new assem::OperInstr("leaq " + name_->Name() + "(%rip), `d0",
                           new temp::TempList(dst), nullptr, nullptr));
  return dst;
}

temp::Temp *ConstExp::Munch(assem::InstrList &instr_list, std::string_view fs) {
  temp::Temp *dst = temp::TempFactory::NewTemp();
  // Imm
  instr_list.Append(
      new assem::OperInstr("movq $" + std::to_string(consti_) + ", `d0",
                           new temp::TempList(dst), nullptr, nullptr));
  return dst;
}

temp::Temp *CallExp::Munch(assem::InstrList &instr_list, std::string_view fs) {
  /* TODO: Put your lab5 code here */
  // TODO: may need to save caller and callee saved regs on stack!!!
  // prepare arguments
  // should be listed as “sources” of the instruction
  temp::TempList *arg_regs = args_->MunchArgs(instr_list, fs);

  // CALL instruction will trash caller saved registers
  // specifies these registers and as “destinations” of the call
  instr_list.Append(new assem::OperInstr(
      "callq " + (static_cast<NameExp *>(fun_))->name_->Name(),
      reg_manager->CallerSaves(), arg_regs, nullptr));
  // get return value
  temp::Temp *return_temp = temp::TempFactory::NewTemp();
  instr_list.Append(
      new assem::MoveInstr("movq `s0, `d0", new temp::TempList(return_temp),
                           new temp::TempList(reg_manager->ReturnValue())));
  // reset sp when existing arguments passed on the stack
  int arg_reg_num = reg_manager->ArgRegs()->GetList().size();
  int arg_stack_num = std::max(int(args_->GetList().size()) - arg_reg_num, 0);
  if (arg_stack_num > 0) {
    instr_list.Append(new assem::OperInstr(
        "addq $" + std::to_string(arg_stack_num * reg_manager->WordSize()) +
            ", `d0",
        new temp::TempList(reg_manager->StackPointer()), nullptr, nullptr));
  }
  return return_temp;
}

temp::TempList *ExpList::MunchArgs(assem::InstrList &instr_list,
                                   std::string_view fs) {
  // ExpList::MunchArgs generates code to move all the arguments to their
  // correct position
  // MunchArgs(il) will iterate exp_list for all arguments , generate
  // corresponding assem to move them all
  temp::TempList *arg_regs = new temp::TempList();
  int arg_idx = 0;
  int arg_reg_num = reg_manager->ArgRegs()->GetList().size();
  for (Exp *exp : exp_list_) {
    temp::Temp *src = exp->Munch(instr_list, fs);
    if (arg_idx < arg_reg_num) {
      // pass in reg
      temp::Temp *reg = reg_manager->ArgRegs()->NthTemp(arg_idx);
      instr_list.Append(new assem::MoveInstr(
          "movq `s0, `d0", new temp::TempList(reg), new temp::TempList(src)));
      arg_regs->Append(reg);
    } else {
      // pass on stack
      // pushq (subq wordsize fo SP, then mov to SP)
      instr_list.Append(new assem::OperInstr(
          "subq $" + std::to_string(reg_manager->WordSize()) + ", `d0",
          new temp::TempList(reg_manager->StackPointer()), nullptr, nullptr));
      instr_list.Append(new assem::OperInstr(
          "movq `s0, (`d0)", new temp::TempList(reg_manager->StackPointer()),
          new temp::TempList(src), nullptr));
    }
    ++arg_idx;
  }
  // returns a list of all the temporaries that are to be passed to the
  // machine’s call instructions
  return arg_regs;
}

} // namespace tree
