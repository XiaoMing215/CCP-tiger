#include <sstream>
#include "tiger/frame/x64frame.h"
#include "frame.h"

extern frame::RegManager *reg_manager;

namespace frame {

int X64Frame::AllocLocal() {
  offset_ -= reg_manager->WordSize();
  return offset_;
}

X64Frame::X64Frame(temp::Label *name, std::list<bool> formals) : Frame(name) {
  formals_ = new std::list<frame::Access *>();
  for (auto formal_escape : formals) {
    formals_->push_back(frame::Access::AllocLocal(this, formal_escape));
  }
}

std::list<frame::Access *> *X64Frame::Formals() { return nullptr; }

int X64Frame::Size() {
  const int arg_num = formals_->size();
  const int arg_reg_num = reg_manager->ArgRegs()->GetList().size();
  return -offset_ + std::max(arg_num - arg_reg_num, 0) * reg_manager->WordSize();
}

temp::TempList *X64RegManager::Registers() {
  return new temp::TempList({
      regs_[RAX],
      regs_[RBX],
      regs_[RCX],
      regs_[RDX],
      regs_[RSI],
      regs_[RDI],
      regs_[RBP],
      regs_[R8],
      regs_[R9],
      regs_[R10],
      regs_[R11],
      regs_[R12],
      regs_[R13],
      regs_[R14],
      regs_[R15],
  });
}

temp::TempList *X64RegManager::ArgRegs() {
  return new temp::TempList({
      regs_[RDI],
      regs_[RSI],
      regs_[RDX],
      regs_[RCX],
      regs_[R8],
      regs_[R9],
  });
}

temp::TempList *X64RegManager::CallerSaves() {
  return new temp::TempList({
      regs_[RAX],
      regs_[RCX],
      regs_[RDX],
      regs_[RSI],
      regs_[RDI],
      regs_[R8],
      regs_[R9],
      regs_[R10],
      regs_[R11],
  });
}

temp::TempList *X64RegManager::CalleeSaves() {
  return new temp::TempList({
      regs_[RBX],
      regs_[RBP],
      regs_[R12],
      regs_[R13],
      regs_[R14],
      regs_[R15],
  });
}

temp::TempList *X64RegManager::ReturnSink() {
  temp::TempList *temp_list = CalleeSaves();
  temp_list->Append(StackPointer());
  temp_list->Append(ReturnValue());
  return temp_list;
}

int X64RegManager::WordSize() {
  return WORD_SIZE;
}

temp::Temp *X64RegManager::FramePointer() {
  return regs_[RBP];
}

temp::Temp *X64RegManager::StackPointer() {
  return regs_[RSP];
}

temp::Temp *X64RegManager::ReturnValue() {
  return regs_[RAX];
}

X64RegManager::X64RegManager() : RegManager() {
  for (std::string reg_name : X64RegNames) {
    temp::Temp *reg = temp::TempFactory::NewTemp();
    temp_map_->Enter(reg, new std::string("%" + reg_name));
    regs_.push_back(reg);
  }
}

tree::Exp *ExternalCall(std::string s, tree::ExpList *args) {
  return new tree::CallExp(new tree::NameExp(temp::LabelFactory::NamedLabel(s)),
                           args);
}

tree::Stm *ProcEntryExit1(frame::Frame *frame, tree::Stm *stm) {
  tree::Stm *res_stm = nullptr;

  tree::Stm *save_callee_stm = new tree::ExpStm(new tree::ConstExp(0));
  temp::TempList *callee_saved = new temp::TempList();
  for (auto reg : reg_manager->CalleeSaves()->GetList()) {
    temp::Temp *dst = temp::TempFactory::NewTemp();
    save_callee_stm =
        new tree::SeqStm(
        save_callee_stm, new tree::MoveStm(new tree::TempExp(dst),
                                                     new tree::TempExp(reg)));
    callee_saved->Append(dst);
  }

  auto arg_reg_num = reg_manager->ArgRegs()->GetList().size();
  auto arg_num = frame->formals_->size();
  int formal_idx = 0;
  tree::SeqStm *view_shift = nullptr, *tail = nullptr;
  for (Access *formal : *(frame->formals_)) {
    tree::Exp *dst =
        formal->ToExp(new tree::TempExp(reg_manager->FramePointer()));
    tree::Exp *src = nullptr;
    if (formal_idx < arg_reg_num) {
      src = new tree::TempExp(reg_manager->ArgRegs()->NthTemp(formal_idx));
    } else {
      src = new tree::MemExp(new tree::BinopExp(
          tree::BinOp::PLUS_OP, new tree::TempExp(reg_manager->FramePointer()),
          new tree::ConstExp((arg_num - formal_idx) *
                             reg_manager->WordSize())));
    }
    tree::MoveStm *move_stm = new tree::MoveStm(dst, src);
    if (!tail) {
      view_shift = tail = new tree::SeqStm(move_stm, nullptr);
    } else {
      tail->right_ = new tree::SeqStm(move_stm, nullptr);
      tail = static_cast<tree::SeqStm *>(tail->right_);
    }
    ++formal_idx;
  }
  if (view_shift) {
    tail->right_ = stm;
    res_stm = view_shift;
  } else {
    res_stm = stm;
  }

  res_stm = new tree::SeqStm(save_callee_stm, res_stm);

  auto saved = callee_saved->GetList().cbegin();
  for (auto reg : reg_manager->CalleeSaves()->GetList()) {
    res_stm = new tree::SeqStm(res_stm, new tree::MoveStm(new tree::TempExp(reg),
                                                  new tree::TempExp(*saved)));
    ++saved;
  }
  delete callee_saved;

  return res_stm;
}

assem::InstrList *ProcEntryExit2(assem::InstrList *body) {
  body->Append(new assem::OperInstr("", new temp::TempList(),
                                    reg_manager->ReturnSink(), nullptr));
  return body;
}

assem::Proc *BuildCompleteProcedure(frame::Frame *frame, assem::InstrList *body) {
  const std::string labelName = temp::LabelFactory::LabelString(frame->frameLabel_);
  const int frameSize = frame->Size();

  std::ostringstream prologueStream;
  prologueStream << ".set " << labelName << "_framesize, " << frameSize << "\n";
  prologueStream << labelName << ":\n";

  bool isMainFunc = (frame->frameLabel_->Name() == "tigermain");
  if (isMainFunc) {
    prologueStream << "subq $8, %rsp\n";
    prologueStream << "movq %rbp, (%rsp)\n";
  }
  prologueStream << "subq $" << frameSize << ", %rsp\n";

  std::ostringstream epilogueStream;
  epilogueStream << "addq $" << frameSize << ", %rsp\n";
  if (isMainFunc) {
    epilogueStream << "movq (%rsp), %rbp\n";
    epilogueStream << "addq $8, %rsp\n";
  }
  epilogueStream << "retq\n";

  return new assem::Proc(prologueStream.str(), body, epilogueStream.str());
}

Access *Access::AllocLocal(Frame *frame, bool escape) {
  if (escape) {
    int offset = frame->AllocLocal();
    return new frame::InFrameAccess(offset);
  } else {
    temp::Temp *newTemp = temp::TempFactory::NewTemp();
    return new frame::InRegAccess(newTemp);
  }
}

tree::Exp *InFrameAccess::ToExp(tree::Exp *framePtr) const {
  auto offsetExp = new tree::ConstExp(offset);
  auto addressExp = new tree::BinopExp(tree::BinOp::PLUS_OP, framePtr, offsetExp);
  return new tree::MemExp(addressExp);
}

tree::Exp *InRegAccess::ToExp(tree::Exp *framePtr) const {
  return new tree::TempExp(reg);
}

} // namespace frame
